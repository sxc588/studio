package com.usermanagersystem.Interceptor;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.usermanagersystem.ImplDao.ImplUser;
import com.usermanagersystem.InterDao.InterUser;

public class GetAllUserInterceptor extends AbstractInterceptor {

	/**
	 * �û���¼ǰ��ʼ������
	 */
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		// TODO Auto-generated method stub
		InterUser interUser=new ImplUser();
		List alluserList=interUser.findAllUsers();//��ѯ�����û���Ϣ
		List alladminList=interUser.findAllAdmins();//��ѯ������ͨ����Ա��Ϣ
		
		invocation.getInvocationContext().getSession().put("alladminList",alladminList);
		invocation.getInvocationContext().getSession().put("alluserList",alluserList);//�Ѳ�ѯ�������ݷ���session
		return invocation.invoke();
	}

}
